﻿using System.Windows;
using пр13_14.Pages;

namespace пр13_14
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            if (!DatabaseHelper.TestConnection())
            {
                MessageBox.Show("Нет соединения с базой данных! Проверьте настройки.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            MainFrame.Navigate(new LoginPage());
        }

        public void UpdateUserInfo()
        {
            if (!string.IsNullOrEmpty(SessionManager.CurrentUserName))
            {
                txtUserName.Text = $"👤 {SessionManager.CurrentUserName}";
            }
            else
            {
                txtUserName.Text = "";
            }
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            SessionManager.ClearSession();
            UpdateUserInfo(); 
            MainFrame.Navigate(new LoginPage());
        }
    }
}