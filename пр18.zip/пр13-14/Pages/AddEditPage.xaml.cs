﻿using Microsoft.Win32;
using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace пр13_14.Pages
{
    public partial class AddEditPage : Page
    {
        private EventCardData _currentEvent;
        private bool _isEditMode;

        public AddEditPage(EventCardData eventToEdit = null)
        {
            InitializeComponent();
            _isEditMode = eventToEdit != null;
            _currentEvent = eventToEdit ?? new EventCardData();

            if (_isEditMode)
            {
                LoadData();
                Title = "Редактирование мероприятия";
            }
            else
            {
                Title = "Новое мероприятие";
                cbType.SelectedIndex = 0;
                cbStatus.SelectedIndex = 0;
                dpDate.SelectedDate = DateTime.Today;
            }
        }

        private void LoadData()
        {
            tbName.Text = _currentEvent.EventName;

            foreach (ComboBoxItem item in cbType.Items)
            {
                if (item.Content.ToString() == _currentEvent.EventType)
                {
                    cbType.SelectedItem = item;
                    break;
                }
            }

            cbStatus.SelectedItem = cbType.Items.Cast<ComboBoxItem>()
                .FirstOrDefault(x => x.Content.ToString() == _currentEvent.Status);

            dpDate.SelectedDate = _currentEvent.EventDate;
            tbBudget.Text = _currentEvent.TotalBudget.ToString();
            tbLocation.Text = _currentEvent.Location;
            tbDescription.Text = _currentEvent.Description;

            if (_currentEvent.Image != null)
            {
                imgPreview.Source = _currentEvent.ImageSource;
            }
        }

        private void BtnLoadImage_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Image files (*.jpg;*.jpeg;*.png)|*.jpg;*.jpeg;*.png";

            if (dialog.ShowDialog() == true)
            {
                byte[] imageData = File.ReadAllBytes(dialog.FileName);
                _currentEvent.Image = imageData;
                imgPreview.Source = _currentEvent.ImageSource;
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbName.Text))
            {
                MessageBox.Show("Введите название мероприятия!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (!decimal.TryParse(tbBudget.Text, out decimal budget))
            {
                MessageBox.Show("Некорректный формат бюджета!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            _currentEvent.EventName = tbName.Text;
            _currentEvent.EventType = (cbType.SelectedItem as ComboBoxItem)?.Content.ToString();
            _currentEvent.Status = (cbStatus.SelectedItem as ComboBoxItem)?.Content.ToString();
            _currentEvent.EventDate = dpDate.SelectedDate ?? DateTime.Today;
            _currentEvent.TotalBudget = budget;
            _currentEvent.Location = tbLocation.Text;
            _currentEvent.Description = tbDescription.Text;

            if (DatabaseHelper.SaveEvent(_currentEvent))
            {
                MessageBox.Show("Успешно сохранено!", "Готово", MessageBoxButton.OK, MessageBoxImage.Information);

                if (Application.Current.MainWindow is MainWindow mw)
                    mw.MainFrame.GoBack();
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.MainWindow is MainWindow mw)
                mw.MainFrame.GoBack();
        }
    }
}