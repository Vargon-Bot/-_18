﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace пр13_14.Pages
{
    public partial class AdminPage : Page
    {
        public AdminPage()
        {
            InitializeComponent();
            LoadUsers();
            LoadAnalytics();
        }

        private void LoadUsers()
        {
            using (var context = new EventOrganizerDBEntities1())
            {
                var users = context.Users.Select(u => new
                {
                    u.UserID,
                    FullName = u.LastName + " " + u.FirstName,
                    u.Email,
                    RoleName = u.RoleID == 1 ? "Админ" : u.RoleID == 2 ? "Менеджер" : "Пользователь"
                    
                }).ToList();

                dgUsers.ItemsSource = users;
            }
        }

        private void LoadAnalytics()
        {
            using (var context = new EventOrganizerDBEntities1())
            {
                txtTotalEvents.Text = context.Events.Count().ToString();
                txtTotalUsers.Text = context.Users.Count().ToString();
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
    }

}