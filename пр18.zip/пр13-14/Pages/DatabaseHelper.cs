﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Windows;
using System.Windows.Media.Imaging;
using System.IO;

namespace пр13_14
{
    public static class DatabaseHelper
    {
        private static EventOrganizerDBEntities1 GetContext()
        {
            return new EventOrganizerDBEntities1();
        }

        public static bool TestConnection()
        {
            try
            {
                using (var context = GetContext())
                {
                    var count = context.Users.Count();
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        public static int? ValidateUser(string login, string password)
        {
            try
            {
                using (var context = GetContext())
                {
                    var user = context.Users.FirstOrDefault(u => u.Login == login && u.Password == password);

                    if (user != null)
                    {
                        SessionManager.CurrentUserID = user.UserID;
                        SessionManager.CurrentRoleID = user.RoleID;
                        SessionManager.CurrentUserName = user.FirstName + " " + user.LastName;

                        return user.RoleID;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
            return null;
        }

        public static List<EventCardData> GetAllEvents()
        {
            using (var context = GetContext())
            {
                return context.Events
                    .Select(e => new EventCardData
                    {
                        EventID = e.EventID,
                        EventName = e.EventName,
                        EventType = e.EventType,
                        EventDate = e.EventDate,
                        Location = e.Location,
                        TotalBudget = e.TotalBudget,
                        Status = e.Status,
                        Description = e.Description,
                        Image = e.Image
                    })
                    .ToList();
            }
        }

        public static bool SaveEvent(EventCardData eventData)
        {
            try
            {
                using (var context = GetContext())
                {
                    Events eventEntity;

                    if (eventData.EventID > 0)
                    {
                        eventEntity = context.Events.FirstOrDefault(e => e.EventID == eventData.EventID);
                        if (eventEntity == null) return false;
                    }
                    else
                    {
                        eventEntity = new Events();
                        context.Events.Add(eventEntity);
                    }

                    eventEntity.EventName = eventData.EventName;
                    eventEntity.EventType = eventData.EventType;
                    eventEntity.EventDate = eventData.EventDate;
                    eventEntity.Location = eventData.Location;
                    eventEntity.TotalBudget = eventData.TotalBudget;
                    eventEntity.Status = eventData.Status;
                    eventEntity.Description = eventData.Description;
                    eventEntity.Image = eventData.Image;
                    eventEntity.ManagerID = 1;

                    context.SaveChanges();
                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }

        public static bool DeleteEvent(int eventId)
        {
            try
            {
                using (var context = GetContext())
                {
                    var eventEntity = context.Events.FirstOrDefault(e => e.EventID == eventId);
                    if (eventEntity != null)
                    {
                        context.Events.Remove(eventEntity);
                        context.SaveChanges();
                        return true;
                    }
                    return false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка удаления: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }

        public static bool RegisterUser(string fullName, string email, string login, string password)
        {
            try
            {
                using (var context = GetContext())
                {
                    if (context.Users.Any(u => u.Login == login))
                    {
                        MessageBox.Show("Пользователь с таким логином уже существует!");
                        return false;
                    }

                    string[] nameParts = fullName.Split(new char[] { ' ' }, 2);
                    string firstName = nameParts[0];
                    string lastName = nameParts.Length > 1 ? nameParts[1] : "";

                    var newUser = new Users
                    {
                        Login = login,
                        Password = password,
                        FirstName = firstName,
                        LastName = lastName,
                        Email = email,
                        RoleID = 3,
                        CreatedAt = DateTime.Now
                    };

                    context.Users.Add(newUser);
                    context.SaveChanges();

                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка регистрации: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }
    }

    public class EventCardData
    {
        public int EventID { get; set; }
        public string EventName { get; set; }
        public string EventType { get; set; }
        public DateTime EventDate { get; set; }
        public string Location { get; set; }
        public decimal TotalBudget { get; set; }
        public string Status { get; set; }
        public string Description { get; set; }
        public byte[] Image { get; set; }

        public BitmapImage ImageSource => GetImageSource();

        private BitmapImage GetImageSource()
        {
            if (Image != null && Image.Length > 0)
            {
                var bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.StreamSource = new MemoryStream(Image);
                bitmap.CacheOption = BitmapCacheOption.OnLoad;
                bitmap.EndInit();
                bitmap.Freeze();
                return bitmap;
            }
            return null;
        }
    }
}