﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace пр13_14.Pages
{
    public partial class LoginPage : Page
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string login = tbLogin.Text;
            string pass = pbPassword.Password;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(pass))
            {
                MessageBox.Show("Заполните все поля!");
                return;
            }

            int? roleId = DatabaseHelper.ValidateUser(login, pass);

            if (roleId.HasValue)
            {
                if (Application.Current.MainWindow is MainWindow mw)
                {
                    mw.UpdateUserInfo();

                    switch (roleId)
                    {
                        case 1:
                            mw.MainFrame.Navigate(new AdminPage());
                            break;
                        case 2:
                            mw.MainFrame.Navigate(new ManagerPage());
                            break;
                        case 3:
                            mw.MainFrame.Navigate(new UserPage());
                            break;
                        default:
                            mw.MainFrame.Navigate(new UserPage());
                            break;
                    }
                }
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль");
            }
        }

        private void GoToRegister_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (Application.Current.MainWindow is MainWindow mw)
                mw.MainFrame.Navigate(new RegistrationPage());
        }
    }
}