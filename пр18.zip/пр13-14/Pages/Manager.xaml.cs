﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace пр13_14.Pages
{
    public partial class ManagerPage : Page
    {
        private List<EventCardData> _allEvents;
        private ICollectionView _collectionView;

        public ManagerPage()
        {
            InitializeComponent();
            LoadEvents();
        }

        private void LoadEvents()
        {
            _allEvents = DatabaseHelper.GetAllEvents();
            _collectionView = CollectionViewSource.GetDefaultView(_allEvents);
            _collectionView.Filter = FilterPredicate;
            ApplySorting();
            lvEvents.ItemsSource = _collectionView;
        }

        private bool FilterPredicate(object obj)
        {
            EventCardData item = obj as EventCardData;
            if (item == null) return false;

            string searchText = tbSearch?.Text?.ToLower() ?? "";
            if (!string.IsNullOrEmpty(searchText))
            {
                if (!item.EventName.ToLower().Contains(searchText) &&
                    !(item.Description ?? "").ToLower().Contains(searchText))
                    return false;
            }

            if (cbFilterStatus?.SelectedItem is ComboBoxItem statusItem)
            {
                string statusFilter = statusItem.Content.ToString();
                if (statusFilter != "Все статусы" && item.Status != statusFilter)
                    return false;
            }

            if (cbFilterType?.SelectedItem is ComboBoxItem typeItem)
            {
                string typeFilter = typeItem.Content.ToString();
                if (typeFilter != "Все типы" && item.EventType != typeFilter)
                    return false;
            }

            return true;
        }

        private void TbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            _collectionView?.Refresh();
        }

        private void Filter_Changed(object sender, SelectionChangedEventArgs e)
        {
            _collectionView?.Refresh();
        }

        private void ApplySorting()
        {
            if (_collectionView == null) return;

            _collectionView.SortDescriptions.Clear();

            if (cbSort?.SelectedItem is ComboBoxItem item)
            {
                string tag = item.Tag?.ToString();

                switch (tag)
                {
                    case "DateDesc":
                        _collectionView.SortDescriptions.Add(new SortDescription("EventDate", ListSortDirection.Descending));
                        break;
                    case "DateAsc":
                        _collectionView.SortDescriptions.Add(new SortDescription("EventDate", ListSortDirection.Ascending));
                        break;
                    case "NameAsc":
                        _collectionView.SortDescriptions.Add(new SortDescription("EventName", ListSortDirection.Ascending));
                        break;
                    case "NameDesc":
                        _collectionView.SortDescriptions.Add(new SortDescription("EventName", ListSortDirection.Descending));
                        break;
                    case "BudgetDesc":
                        _collectionView.SortDescriptions.Add(new SortDescription("TotalBudget", ListSortDirection.Descending));
                        break;
                    case "BudgetAsc":
                        _collectionView.SortDescriptions.Add(new SortDescription("TotalBudget", ListSortDirection.Ascending));
                        break;
                }
            }
        }

        private void Sort_Changed(object sender, SelectionChangedEventArgs e)
        {
            ApplySorting();
        }

        private void LvEvents_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            bool isSelected = lvEvents.SelectedItem != null;
            btnEdit.IsEnabled = isSelected;
            btnDelete.IsEnabled = isSelected;
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.MainWindow is MainWindow mw)
                mw.MainFrame?.Navigate(new AddEditPage());
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            if (lvEvents.SelectedItem is EventCardData selected)
            {
                if (Application.Current.MainWindow is MainWindow mw)
                    mw.MainFrame?.Navigate(new AddEditPage(selected));
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (lvEvents.SelectedItem is EventCardData selected)
            {
                var result = MessageBox.Show($"Удалить '{selected.EventName}'?", "Подтверждение",
                    MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes && DatabaseHelper.DeleteEvent(selected.EventID))
                {
                    LoadEvents();
                    MessageBox.Show("Удалено!");
                }
            }
        }
    }
}