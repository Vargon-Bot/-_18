﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace пр13_14.Converters
{
    public class BoolToButtonColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is bool boolValue)
            {
                return boolValue ?
                    new SolidColorBrush(Color.FromRgb(255, 152, 0)) : 
                    new SolidColorBrush(Color.FromRgb(244, 67, 54));  
            }
            return new SolidColorBrush(Color.FromRgb(158, 158, 158));
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}