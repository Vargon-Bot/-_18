﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace пр13_14.Converters
{
    public class StatusColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string status = value as string;

            if (string.IsNullOrEmpty(status))
                return new SolidColorBrush(Color.FromRgb(158, 158, 158));

            switch (status.ToLower())
            {
                case "planning":
                    return new SolidColorBrush(Color.FromRgb(124, 77, 255));
                case "active":
                    return new SolidColorBrush(Color.FromRgb(76, 175, 80));
                case "completed":
                    return new SolidColorBrush(Color.FromRgb(33, 150, 243));
                case "cancelled":
                    return new SolidColorBrush(Color.FromRgb(244, 67, 54));
                default:
                    return new SolidColorBrush(Color.FromRgb(158, 158, 158));
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}