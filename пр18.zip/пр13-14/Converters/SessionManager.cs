﻿namespace пр13_14
{
    public static class SessionManager
    {
        public static int? CurrentUserID { get; set; }
        public static int? CurrentRoleID { get; set; }
        public static string CurrentUserName { get; set; }

        public static void ClearSession()
        {
            CurrentUserID = null;
            CurrentRoleID = null;
            CurrentUserName = null;
        }
    }
}